package com.ust.EmployeeServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
